import React from "react";
import "./ourfeature.css";
const Ourfeatures = () => {
  return (
    <>
      <div className="section-container py-8">
        <div className="columns-image">
          <img src="https://promo-theme.com/novo-elementor-kit/wp-content/uploads/2021/10/team-of-innovators-2021-09-01-10-50-57-utc-1024x683.jpg" />
        </div>
        <div className="content-text">
          <h2 className="wrap">
            <span className="firstspan">Our{""}</span>
            <span className="secondspan"> features</span>
          </h2>
          <div className="para">
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia
              ipsum sit fugiat blanditiis vero dolore inventore eveniet saepe
              placeat, m Dolorum architecto earum esse soluta laboriosam in at
              maiores voluptatibus nihil saepe quae, assumenda tempore delectus
              ad quod ab molestiae quas! Culpa.
            </p>
          </div>
        </div>
      </div>
    </>
  );
};
export default Ourfeatures;

// import "./App.css";
// import BackgroundImageInterval from "./Components/BackgroundImageInterval";


// function App() {
//   return (
//     <>
//     <BackgroundImageInterval />
//     </>
//   );
// }

// export default App;
